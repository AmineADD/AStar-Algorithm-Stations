Programmation Multi-paradigme (TD3)

*Le fichier jar contient dans ses resources metro.txt 
*Il suffit juste de lancer le programme et de manipuler ce qu'il propose comme service 
*Pour avoir un message d'aide sur le programme il faut l'executer avec l'argument -h